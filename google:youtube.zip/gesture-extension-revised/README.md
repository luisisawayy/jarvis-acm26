# Hand Gesture Browser + YouTube Controller

This is a Chrome extension that assumes MediaPipe is already running somewhere else and has already converted a hand gesture into a number.

There is no popup UI and no manual number input. Your gesture code only needs to feed the number into the extension.

## Gesture number map

| Number | Gesture | Action |
|---:|---|---|
| 1 | Swipe right | Switch to next tab |
| 2 | Swipe left | Switch to previous tab |
| 3 | Swipe up | Open new tab |
| 4 | Swipe down | Close current tab |
| 5 | Zoom out | Minimize window |
| 6 | Zoom in, full hand | Maximize window |
| 7 | Stop sign | YouTube pause/unpause |
| 8 | Two-finger slide right | YouTube skip forward 10 seconds |
| 9 | Two-finger slide left | YouTube skip backward 10 seconds |
| 10 | Two-finger slide up | YouTube volume up |
| 11 | Two-finger slide down | YouTube volume down |
| 12 | Two-finger zoom in | YouTube fullscreen |

## Install the extension

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select this folder.

## How to feed gesture numbers

### Option 1: If your MediaPipe code runs inside extension code

Call:

```js
chrome.runtime.sendMessage({
  type: "GESTURE_NUMBER",
  gesture: gestureNumber
});
```

Example:

```js
function onGestureDetected(gestureNumber) {
  chrome.runtime.sendMessage({
    type: "GESTURE_NUMBER",
    gesture: gestureNumber
  });
}
```

### Option 2: If your MediaPipe code runs inside a normal webpage

Call:

```js
window.postMessage({
  source: "mediapipe-gesture",
  gesture: gestureNumber
}, "*");
```

Example:

```js
function onGestureDetected(gestureNumber) {
  window.postMessage({
    source: "mediapipe-gesture",
    gesture: gestureNumber
  }, "*");
}
```

`gestureBridge.js` listens for that page message and forwards it to `background.js`.

## Main function

The main function is in `background.js`:

```js
async function handleGesture(gestureNumber) {
  // routes the number to the correct browser or YouTube action
}
```

Usually you do not call `handleGesture` directly, because Chrome extension service workers are isolated. Instead, send a message using one of the two methods above.

## YouTube notes

Direct YouTube watch pages work best because the content script can control the actual `<video>` element.

Embedded YouTube iframes are supported through the YouTube iframe `postMessage` API. For best iframe support, the iframe URL should include:

```txt
enablejsapi=1
```

Example iframe URL:

```html
<iframe
  src="https://www.youtube.com/embed/VIDEO_ID?enablejsapi=1"
  allow="fullscreen">
</iframe>
```

A limitation: for cross-origin YouTube iframes, relative seek and true pause/unpause toggling are less reliable than on normal YouTube pages because the parent page cannot directly read the iframe video state.

## Files

- `manifest.json` — Chrome extension config
- `background.js` — gesture routing and Chrome tab/window controls
- `gestureBridge.js` — receives `window.postMessage` gesture numbers from page code
- `youtubeContent.js` — YouTube video and iframe controls
- `mediaPipeAdapter.js` — small helper function you can copy into your MediaPipe code
