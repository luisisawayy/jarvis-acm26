/*
  background.js

  MediaPipe should send a number to this extension using either:

    chrome.runtime.sendMessage({ type: "GESTURE_NUMBER", gesture: 7 });

  from extension code, or:

    window.postMessage({ source: "mediapipe-gesture", gesture: 7 }, "*");

  from normal page code. gestureBridge.js receives that page message and forwards it here.
*/

const GESTURES = Object.freeze({
  SWIPE_RIGHT: 1,        // switch to next tab
  SWIPE_LEFT: 2,         // switch to previous tab
  SWIPE_UP: 3,           // open new tab
  SWIPE_DOWN: 4,         // close current tab
  ZOOM_OUT: 5,           // minimize window
  ZOOM_IN_FULL_HAND: 6,  // maximize window
  STOP_SIGN: 7,          // YouTube pause/unpause
  TWO_SLIDE_RIGHT: 8,    // YouTube skip forward
  TWO_SLIDE_LEFT: 9,     // YouTube skip backward
  TWO_SLIDE_UP: 10,      // YouTube volume up
  TWO_SLIDE_DOWN: 11,    // YouTube volume down
  TWO_ZOOM_IN: 12        // YouTube fullscreen
});

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) throw new Error("No active tab found.");
  return tab;
}

async function switchTab(direction) {
  const current = await getCurrentTab();
  const tabs = await chrome.tabs.query({ currentWindow: true });
  if (tabs.length <= 1) return;

  const currentIndex = tabs.findIndex((tab) => tab.id === current.id);
  const nextIndex = (currentIndex + direction + tabs.length) % tabs.length;
  await chrome.tabs.update(tabs[nextIndex].id, { active: true });
}

async function openNewTab() {
  await chrome.tabs.create({ active: true });
}

async function closeCurrentTab() {
  const current = await getCurrentTab();
  await chrome.tabs.remove(current.id);
}

async function setWindowState(state) {
  const current = await getCurrentTab();
  await chrome.windows.update(current.windowId, { state });
}

async function sendYoutubeAction(action, payload = {}) {
  const current = await getCurrentTab();

  try {
    await chrome.tabs.sendMessage(current.id, {
      type: "YOUTUBE_GESTURE_ACTION",
      action,
      payload
    });
  } catch (error) {
    await chrome.scripting.executeScript({
      target: { tabId: current.id, allFrames: true },
      files: ["youtubeContent.js"]
    });

    await chrome.tabs.sendMessage(current.id, {
      type: "YOUTUBE_GESTURE_ACTION",
      action,
      payload
    });
  }
}

async function handleGesture(gestureNumber) {
  const gesture = Number(gestureNumber);

  switch (gesture) {
    case GESTURES.SWIPE_RIGHT:
      return switchTab(1);

    case GESTURES.SWIPE_LEFT:
      return switchTab(-1);

    case GESTURES.SWIPE_UP:
      return openNewTab();

    case GESTURES.SWIPE_DOWN:
      return closeCurrentTab();

    case GESTURES.ZOOM_OUT:
      return setWindowState("minimized");

    case GESTURES.ZOOM_IN_FULL_HAND:
      return setWindowState("maximized");

    case GESTURES.STOP_SIGN:
      return sendYoutubeAction("togglePlayPause");

    case GESTURES.TWO_SLIDE_RIGHT:
      return sendYoutubeAction("seekBy", { seconds: 10 });

    case GESTURES.TWO_SLIDE_LEFT:
      return sendYoutubeAction("seekBy", { seconds: -10 });

    case GESTURES.TWO_SLIDE_UP:
      return sendYoutubeAction("volumeBy", { amount: 10 });

    case GESTURES.TWO_SLIDE_DOWN:
      return sendYoutubeAction("volumeBy", { amount: -10 });

    case GESTURES.TWO_ZOOM_IN:
      return sendYoutubeAction("fullscreen");

    default:
      console.warn(`Unknown gesture number: ${gestureNumber}`);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "GESTURE_NUMBER") return false;

  handleGesture(message.gesture)
    .then(() => sendResponse({ ok: true }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));

  return true;
});

// Useful when debugging in the extension service-worker console.
self.handleGesture = handleGesture;
self.GESTURES = GESTURES;
