/*
  gestureBridge.js

  This lets normal page code feed gesture numbers into the extension.
  Your MediaPipe code can call:

    window.postMessage({ source: "mediapipe-gesture", gesture: 7 }, "*");

  The bridge forwards that number to background.js, where handleGesture runs.
*/

window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  const data = event.data;
  if (!data || data.source !== "mediapipe-gesture") return;

  chrome.runtime.sendMessage({
    type: "GESTURE_NUMBER",
    gesture: data.gesture
  });
});
