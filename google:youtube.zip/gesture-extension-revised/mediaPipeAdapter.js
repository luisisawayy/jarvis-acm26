/*
  mediaPipeAdapter.js

  Copy this function into the place where your MediaPipe code already decides
  which gesture number happened.

  If the MediaPipe code runs as extension code, use chrome.runtime.sendMessage.
  If the MediaPipe code runs inside a normal webpage, use window.postMessage.
*/

export function feedGestureNumber(gestureNumber) {
  if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
    chrome.runtime.sendMessage({
      type: "GESTURE_NUMBER",
      gesture: gestureNumber
    });
    return;
  }

  window.postMessage({
    source: "mediapipe-gesture",
    gesture: gestureNumber
  }, "*");
}

// Example only:
// onMediaPipeGestureDetected((gestureNumber) => {
//   feedGestureNumber(gestureNumber);
// });
