/*
  youtubeContent.js

  Controls YouTube when the active tab is a YouTube watch page or contains a
  YouTube iframe. For iframes, the iframe URL should include enablejsapi=1.
*/

function getYoutubeIframes() {
  return [...document.querySelectorAll(
    'iframe[src*="youtube.com/embed"], iframe[src*="youtube-nocookie.com/embed"]'
  )];
}

function postToYoutubeIframes(func, args = []) {
  const iframes = getYoutubeIframes();
  let sent = false;

  for (const iframe of iframes) {
    if (!iframe.contentWindow) continue;

    iframe.contentWindow.postMessage(
      JSON.stringify({ event: "command", func, args }),
      "*"
    );
    sent = true;
  }

  return sent;
}

function getVideoElement() {
  return document.querySelector("video");
}

function togglePlayPause() {
  const video = getVideoElement();

  if (video) {
    if (video.paused) video.play();
    else video.pause();
    return;
  }

  // Iframe fallback. YouTube iframe API does not have a perfect toggle command,
  // so this attempts to play. Direct YouTube pages use the video element above.
  postToYoutubeIframes("playVideo");
}

function seekBy(seconds) {
  const video = getVideoElement();

  if (video) {
    video.currentTime = Math.max(0, video.currentTime + seconds);
    return;
  }

  // Iframe API seekTo is absolute, not relative. Without reading iframe state,
  // this fallback jumps to 10 seconds for forward and 0 seconds for backward.
  postToYoutubeIframes("seekTo", [seconds > 0 ? 10 : 0, true]);
}

function volumeBy(amount) {
  const video = getVideoElement();

  if (video) {
    video.volume = Math.min(1, Math.max(0, video.volume + amount / 100));
    video.muted = false;
    return;
  }

  postToYoutubeIframes("unMute");
  postToYoutubeIframes("setVolume", [amount > 0 ? 80 : 20]);
}

function fullscreen() {
  const player =
    document.querySelector(".html5-video-player") ||
    getVideoElement() ||
    getYoutubeIframes()[0];

  if (player?.requestFullscreen) {
    player.requestFullscreen();
  }
}

function runYoutubeAction(action, payload = {}) {
  switch (action) {
    case "togglePlayPause":
      return togglePlayPause();

    case "seekBy":
      return seekBy(Number(payload.seconds || 0));

    case "volumeBy":
      return volumeBy(Number(payload.amount || 0));

    case "fullscreen":
      return fullscreen();

    default:
      console.warn(`Unknown YouTube action: ${action}`);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "YOUTUBE_GESTURE_ACTION") return false;

  try {
    runYoutubeAction(message.action, message.payload);
    sendResponse({ ok: true });
  } catch (error) {
    sendResponse({ ok: false, error: error.message });
  }

  return true;
});
